

export default function LoadingScreen(){
    return (
        <>
            <div className="h-screen w-full text-center min-h-screen flex flex-col items-center  justify-center fixed z=[50000]">
                <div className="max-w-[650px]">
                    <h2 className="uppercase">Loading</h2>
                    <div className="h-[2px] w-[100%] my-2 bg-stone-200"></div>
                    <div>100%</div>
                </div>
            </div>
        </>
    )
}